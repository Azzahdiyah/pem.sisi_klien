import Button from "../Elements/Button";
import CheckBox from "../Elements/CheckBox";
import LabeledInput from "../Elements/LabeledInput";

const FormSignUp = () => {
  return (
    <div className="mt-16">
      <form action="">
        <div className="mb-6">
          <LabeledInput
            label="Name"
            type="text"
            placeholder="Name"
            name="name"
          />
        </div>
        <div className="mb-6">
          <LabeledInput
            label="Email address"
            type="email"
            placeholder="hello@example.com"
            name="email"
          />
        </div>
        <div className="mb-6">
          <LabeledInput
            label="Password"
            type="password"
            placeholder="*************"
            name="password"
          />
        </div>
        <div className="mb-3 flex items-center">
          By continuing, you agree to our terms of service
        </div>
        <Button variant="bg-[#299D91] w-full text-white" type="submit">
          Sign Up
        </Button>
      </form>
    </div>
  );
};

export default FormSignUp;
