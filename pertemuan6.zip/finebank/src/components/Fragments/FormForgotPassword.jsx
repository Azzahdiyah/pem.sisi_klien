import Button from "../Elements/Button";
import CheckBox from "../Elements/CheckBox";
import LabeledInput from "../Elements/LabeledInput";

const FormForgotPassword = () => {
  return (
    <div className="mt-16">
      <div className="mb-8">
        <p className="font-bold text-xl mb-2">Forgot Password?</p>
        <p className="text-gray-500 text-sm">
          Enter your email address to get the password reset link.
        </p>
      </div>
      <form action="">
        <div className="mb-6">
          <LabeledInput
            label="Email address"
            type="email"
            placeholder="hello@example.com"
            name="email"
          />
        </div>
        <Button variant="bg-[#299D91] w-full text-white" type="submit">
          Password Reset
        </Button>
      </form>
    </div>
  );
};

export default FormForgotPassword;
