/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        body: ["Inter"],
        poppins: ["Poppins"],
      },
      colors: {
        primary: "#299D91", // Ganti dengan kode warna yang kamu inginkan
      },
    },
  },
  plugins: [],
};
